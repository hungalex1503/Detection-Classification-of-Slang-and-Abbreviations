from selenium import webdriver
from selenium.webdriver.common.by import By
from time import sleep
import csv

# Khởi tạo driver
driver = webdriver.Edge()  # Sử dụng Microsoft Edge
driver.get('https://www.threads.net/@xminette.24/post/DDlYh2ovmhv')

sleep(10)
# Tìm tất cả các comment trong thread (cập nhật selector với dấu chấm (.) trước mỗi lớp)
comments = driver.find_elements(By.CSS_SELECTOR, '.x1a6qonq.x6ikm8r.x10wlt62.xj0a0fe.x126k92a.x6prxxf.x7r5mf7')

 
with open('comments.csv', 'a', newline='', encoding='utf-8-sig') as file:  # Mở file theo chế độ 'append' (thêm vào)
    writer = csv.writer(file)
    
    # Ghi các comment vào file và in ra màn hình
    for comment in comments:
        comment_text = comment.text
        # Ghi comment vào file CSV
        writer.writerow([comment_text])
        # In comment ra màn hình
        print(comment_text)


# Đóng driver
driver.quit()
